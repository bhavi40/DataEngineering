from pyspark import pipelines as dp
from pyspark.sql.functions import *
from pyspark.sql.types import *

# ── CONFIG ────────────────────────────────────────────────────────────────────
CDR_PATH = "s3://wearable-health-pipeline/raw/cdr/"

# ── SCHEMA ────────────────────────────────────────────────────────────────────
cdr_schema = StructType([
    StructField("cdr_id",             StringType(),   True),
    StructField("customer_id",        StringType(),   True),
    StructField("call_date",          DateType(),     True),
    StructField("call_time",          TimestampType(),True),
    StructField("call_duration_mins", DoubleType(),   True),
    StructField("call_type",          StringType(),   True),
    StructField("destination",        StringType(),   True),
    StructField("charge",             DoubleType(),   True),
    StructField("status",             StringType(),   True),
    StructField("roaming",            IntegerType(),  True)
])

# ── BRONZE — create once, append always ──────────────────────────────────────
# dp.create_streaming_table is idempotent — skips if table already exists
dp.create_streaming_table(
    name    = "telecom.bronze.bronze_cdr",
    comment = "Raw CDR records ingested via Autoloader — append only"
)

@dp.append_flow(target = "telecom.bronze.bronze_cdr")
def bronze_cdr_flow():
    return (
        spark.readStream
            .format("cloudFiles")
            .option("cloudFiles.format", "csv")
            .option("header",            "true")
            .schema(cdr_schema)
            .load(CDR_PATH)
            .withColumn("ingested_at", current_timestamp())
            .withColumn("source_file", col("_metadata.file_path"))
    )

# ── SILVER — create once, append always ──────────────────────────────────────
dp.create_streaming_table(
    name    = "telecom.silver.silver_cdr",
    comment = "Cleaned and validated CDR with derived columns — append only",
    expect_all_or_drop = {
        "valid_cdr_id":          "cdr_id IS NOT NULL",
        "valid_customer":        "customer_id IS NOT NULL",
        "valid_duration":        "call_duration_mins > 0",
        "valid_charge":          "charge >= 0",
        "no_future_dates":       "call_date <= current_date()",
        "valid_customer_format": "customer_id LIKE 'CUST%'"
    },
    expect_all = {
        "reasonable_duration": "call_duration_mins <= 600",
        "reasonable_charge":   "charge <= 1000",
        "valid_status":        "status IN ('completed','missed','dropped','busy')",
        "valid_call_type":     "call_type IN ('local','long_distance','international','toll_free')"
    }
)

@dp.append_flow(target = "telecom.silver.silver_cdr")
def silver_cdr_flow():
    return (
        spark.readStream
            .table("telecom.bronze.bronze_cdr")
            .dropDuplicates(["cdr_id"])
            .withColumn("call_date",
                        to_date(col("call_date")))
            .withColumn("call_duration_mins",
                        round(col("call_duration_mins"), 2))
            .withColumn("charge",
                        round(col("charge"), 4))
            .withColumn("call_duration_secs",
                        (col("call_duration_mins") * 60).cast(IntegerType()))
            .withColumn("is_international",
                        when(col("call_type") == "international", 1).otherwise(0))
            .withColumn("is_dropped",
                        when(col("status") == "dropped", 1).otherwise(0))
            .withColumn("is_missed",
                        when(col("status") == "missed", 1).otherwise(0))
            .withColumn("call_hour",
                        hour(col("call_time")))
            .withColumn("is_peak_hour",
                        when(col("call_hour").between(8, 20), 1).otherwise(0))
            .withColumn("revenue_per_minute",
                        when(col("call_duration_mins") > 0,
                            round(col("charge") / col("call_duration_mins"), 4))
                        .otherwise(0.0))
            .select(
                "cdr_id", "customer_id", "call_date", "call_time",
                "call_duration_mins", "call_type", "destination",
                "charge", "status", "roaming",
                "call_duration_secs", "is_international", "is_dropped",
                "is_missed", "call_hour", "is_peak_hour",
                "revenue_per_minute", "ingested_at", "source_file"
            )
    )