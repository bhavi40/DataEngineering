from pyspark import pipelines as dp
from pyspark.sql.functions import *
from pyspark.sql.types import *

# ── CONFIG ────────────────────────────────────────────────────────────────────
EVENTS_PATH = "s3://wearable-health-pipeline/raw/network_events/"

# ── SCHEMA ────────────────────────────────────────────────────────────────────
events_schema = StructType([
    StructField("event_id",        StringType(), True),
    StructField("customer_id",     StringType(), True),
    StructField("tower_id",        StringType(), True),
    StructField("timestamp",       StringType(), True),
    StructField("event_date",      StringType(), True),
    StructField("event_type",      StringType(), True),
    StructField("signal_strength", DoubleType(), True),
    StructField("data_speed_mbps", DoubleType(), True),
    StructField("resolution",      StringType(), True),
    StructField("duration_secs",   LongType(),   True),
    StructField("severity",        StringType(), True)
])

# ── BRONZE — create once, append always ──────────────────────────────────────
dp.create_streaming_table(
    name    = "telecom.bronze.bronze_network_events",
    comment = "Raw network events ingested via Autoloader — append only"
)

@dp.append_flow(target = "telecom.bronze.bronze_network_events")
def bronze_network_events_flow():
    return (
        spark.readStream
            .format("cloudFiles")
            .option("cloudFiles.format", "json")
            .option("multiLine",         "true")
            .schema(events_schema)
            .load(EVENTS_PATH)
            .withColumn("ingested_at", current_timestamp())
            .withColumn("source_file", col("_metadata.file_path"))
    )

# ── SILVER — create once, append always ──────────────────────────────────────
dp.create_streaming_table(
    name    = "telecom.silver.silver_network_events",
    comment = "Cleaned network events with derived columns — append only",
    expect_all_or_drop = {
        "valid_event_id":             "event_id IS NOT NULL",
        "valid_customer":             "customer_id IS NOT NULL",
        "valid_tower":                "tower_id IS NOT NULL",
        "physically_possible_signal": "signal_strength >= -120 OR signal_strength IS NULL"
    },
    expect_all = {
        "valid_data_speed": "data_speed_mbps >= 0",
        "valid_severity":   "severity IN ('low','medium','high','critical')",
        "valid_event_type": "event_type IN ('dropped_call','poor_signal','data_throttle','tower_outage','handoff_failure','network_congestion','reconnect_success')"
    }
)

@dp.append_flow(target = "telecom.silver.silver_network_events")
def silver_network_events_flow():
    return (
        spark.readStream
            .table("telecom.bronze.bronze_network_events")
            .dropDuplicates(["event_id"])
            .withColumn("event_date",
                        to_date(col("event_date")))
            .withColumn("event_timestamp",
                        to_timestamp(col("timestamp")))
            .withColumn("signal_strength",
                        when(col("signal_strength").isNull(), -95.0)
                        .otherwise(col("signal_strength")))
            .withColumn("is_dropped_call",
                        when(col("event_type") == "dropped_call", 1).otherwise(0))
            .withColumn("is_outage",
                        when(col("event_type") == "tower_outage", 1).otherwise(0))
            .withColumn("is_critical",
                        when(col("severity") == "critical", 1).otherwise(0))
            .withColumn("signal_quality",
                        when(col("signal_strength") >= -70,  "excellent")
                        .when(col("signal_strength") >= -85,  "good")
                        .when(col("signal_strength") >= -100, "poor")
                        .otherwise("no_signal"))
            .withColumn("duration_mins",
                        round(col("duration_secs") / 60, 2))
            .drop("timestamp")
            .select(
                "event_id", "customer_id", "tower_id",
                "event_date", "event_timestamp", "event_type",
                "signal_strength", "signal_quality",
                "data_speed_mbps", "resolution",
                "duration_secs", "duration_mins", "severity",
                "is_dropped_call", "is_outage", "is_critical",
                "ingested_at", "source_file"
            )
    )